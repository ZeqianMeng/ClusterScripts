# this script is the generic script for jobsubmission invoked by submitjob.sh
# it is converted into the jobtest.sh that is submitted by the script jobtest_setup.sh 
#! /bin/bash
# commands to qsub to set up the job array and the parallel environment
#$ -S /bin/bash 
#$ -V
#$ -cwd
#$ -pe smp.pe 8
# set base directory and read job parameters from message.txt, created by submitjob.sh
BASE=$HOME/scratch/parallel
{
read numjobs
read ca_start ca_end
read nefold
} <$BASE/message.txt
# data.inp is the template for the parameter file that will be read by nalnpar
if [ -e data.inp ] 
then
rm $BASE/data.inp
fi
# template line for size of job array 5 is written with num_jobs by ca_setup an executable
# 
#$ -t 1-5
jobdir=$BASE/ca$SGE_TASK_ID
#jobdir=$BASE/runs
# create the job directories for the array, if they do not currently exist.
if [ ! -d $jobdir ] 
then
mkdir $jobdir
echo "new directory $jobdir created"
fi
cd $jobdir
# copy startup files and parameter files necessary for nalnpar to run
if [ ! -f pminus.bin ]
then 
cp $BASE/NormalRun/*.bin $BASE/NormalRun/*.dat $jobdir
echo "no bin files in directory"
fi
echo "$numjobs" > $jobdir/data.inp
echo "$ca_start" "$ca_end" >> $jobdir/data.inp
echo "$nefold" >>$jobdir/data.inp 
echo "$SGE_TASK_ID" >>$jobdir/data.inp
# ca_setup prepares the parameter file nalnpar.par with the correct calpha value for each
# directory. It is a compiled f90 program since the shell cannot do the necessary arithmetic.
$BASE/ca_setup
cp $BASE/nalnpar $jobdir/nalnpar
#run the parallel executable in each directory of the array
mpirun -n $NSLOTS ./nalnpar <$jobdir/nalnpar.inp  $jobdir/nalnpar >$jobdir/results
echo "$numjobs"
echo "$ca_start $ca_end"
echo "$nefold"
