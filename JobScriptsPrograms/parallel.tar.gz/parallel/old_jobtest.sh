#! /bin/bash
#$ -S /bin/bash
#$ -V
#$ -cwd
BASE=$HOME/scratch/parallel
{
read numjobs
read ca_start ca_end
read nefold
} <$BASE/message.txt
if [ -e data.inp ] 
then
rm $BASE/data.inp
fi
jobdir=$BASE/runs
if [ ! -d $jobdir ] 
then
mkdir $jobdir
echo "new directory $jobdir created"
fi
cd $jobdir
if [ ! -f pminus.bin ]
then 
cp $BASE/NormalRun/*.bin $BASE/NormalRun/*.dat $jobdir
echo "no bin files in directory"
fi
echo "$numjobs" > $jobdir/data.inp
echo "$ca_start" "$ca_end" >> $jobdir/data.inp
echo "$nefold" >>$jobdir/data.inp 
echo "1" >>$jobdir/data.inp
$BASE/ca_setup
cp $BASE/nalnpar $jobdir/nalnpar

 mpirun -np 4  $jobdir/nalnpar 
echo "$numjobs"
echo "$ca_start $ca_end"
echo "$nefold"
