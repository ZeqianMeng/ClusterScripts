# script to setup the number of jobs in the jobarray
# the eval line replaces zzzz in jobtestraw.sh with the value of numjobs
read numjobs <message.txt
eval sed 's/zzzz/$numjobs/g' <jobtestraw.sh >jobtest.sh
#qsub jobtest
