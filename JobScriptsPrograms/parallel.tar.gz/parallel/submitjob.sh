#! /bin/bash
# script to intitiate a job array of parallel jobs
#usage ./submitjob num_jobs calpha_start calpha_end nefold
# num_jobs is the number of jobs in the array
# calpha_start is the starting value of the parameter
# calpha_end is the finishing value of the parameter
# nefold controls the number of iterations (it is an e-folding time for the decay modes)
numjobs=$1
calpha_start=$2
calpha_end=$3
nefold=$4
echo "$numjobs" >message.txt
echo "$calpha_start $calpha_end" >>message.txt
echo "$nefold">>message.txt
cat message.txt
# take the generic jobtestraw.sh and put in the bespoke values for the run
./jobtest_setup.sh
chmod u+x jobtest.sh
qsub jobtest.sh
