#! /bin/bash
#$ -S /bin/bash
#$ -V
#$ -cwd
#$ -t 1-2
 ./nalnpar <data.$SGE_TASK_ID >results.$SGE_TASK_ID
