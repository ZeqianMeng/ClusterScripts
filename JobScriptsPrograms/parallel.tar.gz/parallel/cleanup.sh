rm jobtest.sh.*[eo]*
rm -rf ca[0-9]*
