rm jobtest.sh.*[eo]*.?*
