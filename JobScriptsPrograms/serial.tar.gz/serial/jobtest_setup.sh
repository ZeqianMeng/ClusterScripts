read numjobs <message.txt
eval sed 's/zzzz/$numjobs/g' <jobtestraw.sh >jobtest.sh
#qsub jobtest
