import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class ClusterJobSubmit {
	public static void main(String[] args) throws IOException{
		//need to get input as broker_job_id, also for job submission parameters
		final String command;
		String numjobs = args[0];
		String nefold = args[3];
		Runtime rt = Runtime.getRuntime();
		command = "/mnt/iusers01/zk01/mbaxjzm3/scratch/serial/submitjob.sh" + " " + numjobs + " 5 7 " + nefold;
        
		Process pr = rt.exec(command);
		BufferedReader stdInput = new BufferedReader(new
                                                     InputStreamReader(pr.getInputStream()));
		
		String s;
		while ((s = stdInput.readLine()) != null){
        	//String s = stdInput.readLine();
        	System.out.println(s);
        	//pw.println(s);
		}
		stdInput.close();
	}
    
}