#! /bin/bash
#$ -S /bin/bash
#$ -V
#$ -cwd
BASE=$HOME/scratch/serial
{
read numjobs
read ca_start ca_end
read nefold
} <$BASE/message.txt
#if [ -e data.inp ] 
#then
#rm $BASE/data.inp
#fi
#echo "$numjobs" >data.inp
#\n $ca_start $ca_end \n 1000 \n $nefold" >data.inp
#$ -t 1-1
jobdir=$BASE/ca$SGE_TASK_ID
if [ ! -d $jobdir ]; then
mkdir $jobdir
echo "new directory $jobdir created"
fi
cd $jobdir
if [ ! -f pminus.bin ]
then 
cp $BASE/NormalRun/*.bin $BASE/NormalRun/*.dat $jobdir
echo "no bin files in directory"
fi
echo "$numjobs" > $jobdir/data.inp
echo "$ca_start" "$ca_end" >> $jobdir/data.inp
echo "$nefold" >>$jobdir/data.inp 
echo "$SGE_TASK_ID" >>$jobdir/data.inp
$BASE/ca_setup
cp $BASE/nalnpar $jobdir/nalnpar

 $jobdir/nalnpar <$jobdir/nalnpar.inp >$jobdir/results.$SGE_TASK_ID
echo "$numjobs"
echo "$ca_start $ca_end"
echo "$nefold"
