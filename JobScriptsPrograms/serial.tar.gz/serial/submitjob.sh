numjobs=$1
calpha_start=$2
calpha_end=$3
nefold=$4
echo "$numjobs" >message.txt
echo "$calpha_start $calpha_end" >>message.txt
echo "$nefold">>message.txt
cat message.txt
./jobtest_setup.sh
chmod u+x jobtest.sh
qsub jobtest.sh
